 NOTE:

 Weather application link : prasadweather.ccbp.tech 
              
 Techstack used : HTML, CSS, JavaScript

 Weather API : https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}

 My API KEY : d361bb07ea372350f451883e25dcdd6c (from OpenWeatherMap.org)
